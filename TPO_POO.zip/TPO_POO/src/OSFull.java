public class OSFull extends ObraSocial {

    public OSFull() {
        super();
    }

    @Override
    public boolean podesCubrir(Tratamiento tratamiento) {
        return true;
    }
}
