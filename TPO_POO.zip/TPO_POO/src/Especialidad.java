public class Especialidad {

    public Especialidad(){

    }
}
