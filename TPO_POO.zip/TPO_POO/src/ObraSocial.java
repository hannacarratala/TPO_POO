public abstract class ObraSocial {

    public ObraSocial(){

    }

    public abstract boolean podesCubrir(Tratamiento tratamiento);


}
